﻿using Sandbox.Game.EntityComponents;
using Sandbox.Game.Weapons;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game.VisualScripting.Missions;
using VRageMath;
using VRageRender;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        //ArcBotCyberSelfActDestr

        private const double TimeStep = 0.016;
        const string MissileTag = "PVE";
        const string ScriptGroupName = "UDR";

        const int GuidanceDelay = 0;
        const int TicksPerSecond = 60;

        //MyItemType NukeAmmoDef = MyItemType.Parse("MyObjectBuilder_AmmoMagazine/SemiAutoPistolMagazine");
        MyItemType NukeAmmoDef = MyItemType.Parse("MyObjectBuilder_AmmoMagazine/FlareClip");

        int NukeAmmoAmount = 10000;
        bool SetupCompleted = false;

        bool HasRaycast = false;
        bool HasHud = false;
        bool InFireSequence = false;

        IMyShipController Reference;

        RaycastHoming RC;

        List<DeviationCorrector> ActiveMissiles = new List<DeviationCorrector>();
        HashSet<IMyShipMergeBlock> ProtoMissiles = new HashSet<IMyShipMergeBlock>();
        List<IMyShipController> Controllers = new List<IMyShipController>();
        List<IMyCameraBlock> RaycastArray = new List<IMyCameraBlock>();
        IMyTextPanel Hud;

        float RaycastRange = 10000;

        Random Rand = new Random();

        public static long Ticks = 0;

        public Program()
        {
            Runtime.UpdateFrequency = UpdateFrequency.Update1;
        }

        public void Main(string argument, UpdateType updateSource)
        {

            if (!Setup())
            {
                return;
            }
            if(Ticks % 20 == 0)
                DisplayInfo();

            if (InFireSequence)
            {
                InFireSequence = false;
                return;
            }

            HandleCommands(argument);
            UpdateMissileTargets();
            UpdateMissiles(ref ActiveMissiles);

            if (HasRaycast)
            {
                RC.Update(TimeStep, RaycastArray, Controllers);
            }
           
            GetMissiles(ref ProtoMissiles);        
        }

        void HandleCommands(string argument)
        {
            if (argument == string.Empty)         
                return;                         
            var argumentParts = argument.Trim().ToLower().Split(new char[] { ' ' }, 2);
            var command = argumentParts[0];
            var commandArguments = argumentParts.Length > 1 && argumentParts[1].Trim().Length > 0 ? argumentParts[1].Trim() : null;

            switch (command)
            {
                case "fire":
                    FireCommand(commandArguments);
                    break;
                case "raycast":
                    Raycast();
                    break;
                case "reload":
                    Reload();
                    break;
                case "detonate":
                    DetonateMissiles();
                    break;
            }
        }


        void Raycast()
        {
            if (!HasRaycast)
                return;

            if (RC.IsScanning || RC.Status == RaycastHoming.TargetingStatus.Locked)
                RC.ClearLock();
            else
                RC.LockOn();
        }

        void FireCommand(string nameFilter = null)
        {
            var missile = GetMissile(nameFilter);
            if (missile == null)
            {
                Echo("There are no missiles ready to fire.");
                return;
            }

            FireMissile(missile, GuidanceDelay * TicksPerSecond);
            InFireSequence = true;
        }

        string[] Ani = { ".", "..", "...", "....", ".....", };
        int cycle = 0;

        string Animate()
        {
            cycle++;
            if (cycle == Ani.Length)
                cycle = 0;

            return Ani[cycle];
        }
        void DisplayInfo()
        {
            if (!HasHud)
                return;

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"-UDR Missile Script-");
            sb.AppendLine($"Active Missiles: {ActiveMissiles.Count}\n Missiles Left: {ProtoMissiles.Count}");
            if (RC.IsScanning && RC.Status == RaycastHoming.TargetingStatus.NotLocked)
            {
                sb.AppendLine($"Scanning{Animate()}");
            }
            else if (RC.IsScanning && RC.Status == RaycastHoming.TargetingStatus.Locked)
            {
                sb.AppendLine($"Target Locked!");
                sb.AppendLine($"Name: {RC.TargetName}");
                sb.AppendLine($"Distance: {Math.Round(Vector3D.Distance(RC.TargetPosition, Me.GetPosition()))} m");
            }

            if (Hud == null || Hud.Closed)
                return;
            sb.AppendLine($"-Debug-\nTimeSinceLastLock {RC.TicksSinceLastLock}");

            Hud.WriteText(sb);
        }


        void DetonateMissiles()
        {
            foreach (var missile in ActiveMissiles)
            {
                missile.NukeOverride = true;
            }
        }

        void RedirectMissiles()
        {
            long entityId = 0;
            Vector3D location = Vector3D.Zero;

            if (RC.Status != RaycastHoming.TargetingStatus.Locked)
                return;
            entityId = RC.TargetId;
            location = RC.TargetPosition;

            if (location == Vector3D.Zero)
                return;

            foreach (var missile in ActiveMissiles)
            {
                missile.ReassignTarget(entityId, location);
            }
        }

        IMyShipMergeBlock GetMissile(string name = null)
        {
            return ProtoMissiles.FirstOrDefault(missile => name == null || missile.CustomName.ToLower().Contains(name));
        }

        void FireMissile(IMyShipMergeBlock mergeBlock, int trackingDelay = 0, long entityId = 0)
        {
            if (ActiveMissiles.Exists(m => m.Merge == mergeBlock))
            {
                throw new Exception("Attempted to fire a missile that was already fired.");
            }

            var blocks = new List<IMyTerminalBlock>();
            GridTerminalSystem.GetBlocks(blocks);

            var missile = new DeviationCorrector(mergeBlock, blocks, Reference, $"Missile-{Rand.Next(1, 20000)}", trackingDelay);

            if (!HasRaycast || RC.Status != RaycastHoming.TargetingStatus.Locked)
                return;

            missile.TargetId = RC.TargetId;
            missile.FireMissile(RC.TargetPosition);

            ActiveMissiles.Add(missile);
            ProtoMissiles.Remove(mergeBlock);

            Echo("Missile launched!");
        }


        void UpdateMissileTargets()
        {
            if (RC.Status == RaycastHoming.TargetingStatus.Locked)
            {
               
                foreach (var missile in ActiveMissiles)
                {
                    missile.TicksSinceLastTargetUpdate = RC.TicksSinceLastLock;
                    missile.TargetId = RC.TargetId;
                    missile.TargetPosition = RC.TargetPosition;
                    missile.HitPositionPosition = RC.HitPosition;
                }
                return;
            } 
        }


        bool Setup()
        {
            if (SetupCompleted)
                return true;

            var tempControllers = new List<IMyShipController>();
            GridTerminalSystem.GetBlocksOfType(tempControllers);
            if (tempControllers.Count == 0)
            {
                Echo("Setup Failed, No ship controllers found.");
                return false;
            }
            Reference = tempControllers.First();

            var scriptGroup = GridTerminalSystem.GetBlockGroupWithName(ScriptGroupName);

            if (scriptGroup == null)
            {
                Echo($"Setup Failed, no group named {ScriptGroupName} found.");
                return false;
            }

            var tempBlocks = new List<IMyTerminalBlock>();
            scriptGroup.GetBlocks(tempBlocks);

            var cameras = tempBlocks.FindAll(b => b is IMyCameraBlock);
            if (cameras.Count > 0)
            {
                HasRaycast = true;
                foreach (var block in cameras)
                {                
                    RaycastArray.Add(block as IMyCameraBlock);
                    ((IMyCameraBlock)block).EnableRaycast = true;
                }
                RC = new RaycastHoming(RaycastRange, 3, 250, Me.CubeGrid.EntityId);
                RC.OffsetTargeting = true;
                RC.AddEntityTypeToFilter(MyDetectedEntityType.FloatingObject, MyDetectedEntityType.Planet, MyDetectedEntityType.Asteroid);

                var _mechConnections = new List<IMyMechanicalConnectionBlock>();
                GridTerminalSystem.GetBlocksOfType(_mechConnections);
                RC.ClearIgnoredGridIDs();
                RC.AddIgnoredGridID(Me.CubeGrid.EntityId);
                foreach (var mc in _mechConnections)
                {
                    RC.AddIgnoredGridID(mc.CubeGrid.EntityId);
                    if (mc.TopGrid != null)
                        RC.AddIgnoredGridID(mc.TopGrid.EntityId);
                }
            }
            GridTerminalSystem.GetBlocksOfType(Controllers);

            Hud = GridTerminalSystem.GetBlockWithName("Hud") as IMyTextPanel;
            Hud.CustomData = "hudlcd:0.6:0.5::255,165,0";
            Hud.ContentType = ContentType.TEXT_AND_IMAGE;
            HasHud = true;
       

            Echo($"Setup Complete. LCD named Hud found = {Hud == null}");
            SetupCompleted = true;
            return true;
        }


        void UpdateMissiles(ref List<DeviationCorrector> activeMissiles)
        {
            activeMissiles.RemoveAll(m => m.Merge.Closed);
            activeMissiles.ForEach(m => m.Update());
        }

        void GetMissiles(ref HashSet<IMyShipMergeBlock> missiles)
        {
            var mergeBlocks = new List<IMyShipMergeBlock>();
            GridTerminalSystem.GetBlocksOfType(mergeBlocks);
            missiles.RemoveWhere(b => b.Closed || b == null);
            foreach (var block in mergeBlocks)
            {
                if (missiles.Contains(block))
                    continue;

                if (!(block is IMyShipMergeBlock))
                    continue;

                if (!block.CustomName.Contains(MissileTag))
                    continue;

                if (ActiveMissiles.Exists(active => active.Merge == block))
                    continue;

                missiles.Add(block);
            }
        }

        bool IsMissileBlock(IMyTerminalBlock block)
        {
            return block.CustomName.Contains(MissileTag);
        }

        void ConnectConnectors()
        {
            var connectors = new List<IMyShipConnector>();
            GridTerminalSystem.GetBlocksOfType(connectors, IsMissileBlock);
            connectors.ForEach(connector =>
            {
                connector.Enabled = true;
                connector.Connect();
            });
        }
        void StockpileTanks()
        {
            var tanks = new List<IMyGasTank>();
            GridTerminalSystem.GetBlocksOfType(tanks, IsMissileBlock);
            tanks.ForEach(c =>
            {
                c.Enabled = true;
                c.Stockpile = true;
            });
        }
        void RechargeBatteries()
        {
            var batteries = new List<IMyBatteryBlock>();
            GridTerminalSystem.GetBlocksOfType(batteries, IsMissileBlock);
            batteries.ForEach(battery =>
            {
                battery.Enabled = true;
                battery.ChargeMode = ChargeMode.Recharge;
            });
        }
        void DisableThrusters()
        {
            var thrusters = new List<IMyThrust>();
            GridTerminalSystem.GetBlocksOfType(thrusters, IsMissileBlock);
            thrusters.ForEach(thruster =>
            {
                thruster.Enabled = false;
            });
        }
        void DisableGyros()
        {
            var gyros = new List<IMyGyro>();
            GridTerminalSystem.GetBlocksOfType(gyros, IsMissileBlock);
            gyros.ForEach(gyro =>
            {
                gyro.Enabled = false;
            });
        }
        List<IMyInventory> GetMissileInventories()
        {
            var missileInventories = new List<IMyInventory>();

            var missileCargos = new List<IMyCargoContainer>();
            GridTerminalSystem.GetBlocksOfType(missileCargos, IsMissileBlock);
            foreach (var cargo in missileCargos)
            {
                missileInventories.Add(cargo.GetInventory());
            }
            var connectors = new List<IMyShipConnector>();
            GridTerminalSystem.GetBlocksOfType(connectors, b => IsMissileBlock(b) && b.CustomName.Contains("Cargo"));
            foreach (var connector in connectors)
            {
                missileInventories.Add(connector.GetInventory());
            }

            return missileInventories;
        }
        void FillCargo()
        {
            var shipCargos = new List<IMyCargoContainer>();
            GridTerminalSystem.GetBlocksOfType(shipCargos, b => !IsMissileBlock(b) && b.GetInventory().ContainItems(1, NukeAmmoDef));

            var missileInventories = GetMissileInventories();

            foreach (var shipCargo in shipCargos)
            {
                foreach (var missileInventory in missileInventories)
                {
                    if (missileInventory.IsFull)
                    {
                        continue;
                    }
                    var current = missileInventory.GetItemAmount(NukeAmmoDef);
                    var transferAmount = NukeAmmoAmount - current;
                    if (transferAmount <= 0)
                    {
                        continue;
                    }

                    var shipCargoInventory = shipCargo.GetInventory();
                    var item = shipCargoInventory.FindItem(NukeAmmoDef);
                    if (item == null)
                    {
                        break;
                    }

                    shipCargoInventory.TransferItemTo(missileInventory, item.Value, transferAmount);
                }
            }
        }

        void Reload()
        {
            Echo("Connecting connectors...");
            ConnectConnectors();
            Echo("Setting tanks to stockpile...");
            StockpileTanks();
            Echo("Setting batteries to recharge...");
            RechargeBatteries();
            // Disable these blocks to avoid unnecessary dampening, fuel burn, and subgrid damage
            Echo("Disabling missile thrusters...");
            DisableThrusters();
            Echo("Disabling missile gyros...");
            DisableGyros();
            Echo("Filling missile cargo containers...");
            FillCargo();

            Echo("Reloading complete.");
        }


        class DeviationCorrector
        {
            public IMyShipMergeBlock Merge { get; }
            public string Id { get; set; }
            public string HudText { get; set; }
            public long TargetId { get; set; }

            public List<IMyShipConnector> Connectors
            {
                get { return _connectors; }
            }
            public long TicksSinceLastTargetUpdate
            {
                get { return _ticksSinceLastUpdate; }
                set 
                {
                    if (value == 0)
                        value = 1;
                    _ticksSinceLastUpdate = value; 
                }             
            }
            public List<IMyCargoContainer> CargoContainers
            {
                get { return _cargoContainers; }
            }
            public List<IMyGasTank> HydrogenTanks
            {
                get { return _hydrogenTanks; }
            }
            public List<IMyThrust> Thrusters
            {
                get { return _thrusters; }
            }
            public List<IMyWarhead> Warheads
            {
                get { return _warheads; }
            }
            public List<IMyGyro> Gyros
            {
                get { return _gyros; }
            }
            public List<IMyBatteryBlock> BatteryBlocks
            {
                get { return _batteryBlocks; }
            }
            public List<IMyProgrammableBlock> ProgrammableBlocks
            {
                get { return _programmableBlocks; }
            }
            public bool NukeOverride
            {
                set { _nukeOverride = value; }
            }

            public List<IMyTerminalBlock> Debug
            {
                get { return _blockList; }
            }
            public bool Launched { get; set; }
            public Vector3D TargetPosition { get; set; }
            public Vector3D HitPositionPosition { get; set; }
            public List<Vector3D> PathToTarget { get; set; }
            public IMyShipController ExternalReference { get; set; }
            public float DistanceToTarget
            {
                get { return (float)Vector3D.Distance(Position, TargetPosition); }
            }
            public Vector3D Position
            {
                get
                {
                    return GetPosition();
                }
            }
            public bool MissileReady { get; private set; }



            public DeviationCorrector(IMyShipMergeBlock mergeBlock, List<IMyTerminalBlock> blocks, IMyShipController reference, string id = "Missile", int trackingDelay = 0)
            {
                Merge = mergeBlock;
                _blockList = blocks;
                Id = id;
                TargetPosition = Vector3D.Zero;
                Launched = false;
                ExternalReference = reference;             
                _trackingDelay = trackingDelay;
            }

            public void FireMissile(Vector3D target)
            {
                Launched = true;
                TargetPosition = target;
                Merge.Enabled = false;
            }


            private bool Setup()
            {
                if (!_tickWaited)
                {
                    _tickWaited = true;
                    return false;
                }

                _blockList.RemoveAll(b => b == null || b.Closed);
                _blockList.RemoveAll(b => b.CubeGrid == ExternalReference.CubeGrid || this.Merge.CubeGrid != b.CubeGrid);
                _iceManager = new IceManager();               
                foreach (var block in _blockList)
                {
                    if (block is IMyShipConnector)
                    {
                        _connectors.Add(block as IMyShipConnector);
                        ((IMyShipConnector)block).Disconnect();
                        if(block.CustomName.Contains("[ice]"))
                        {
                            _iceManager.IceInventory = block.GetInventory();
                        }
                        if (block.CustomName.Contains("[ammo]"))
                        {
                            _nuke = new Nuke(block as IMyShipConnector);
                        }
                        continue;
                    }
                    if (block is IMyGasGenerator)
                    {
                        _iceManager.Generators.Add(block as IMyGasGenerator);
                        continue;
                    }
                    if (block is IMyCargoContainer)
                    {
                        _cargoContainers.Add(block as IMyCargoContainer);

                        continue;
                    }
                    if (block is IMyGasTank)
                    {
                        _hydrogenTanks.Add(block as IMyGasTank);
                        ((IMyGasTank)block).Enabled = true;
                        ((IMyGasTank)block).Stockpile = false;
                        continue;
                    }
                    if (block is IMyThrust)
                    {
                        _thrusters.Add(block as IMyThrust);
                        ((IMyThrust)block).Enabled = true;
                        if (_forwardVector == Vector3D.Zero)
                            _forwardVector = block.WorldMatrix.Backward;
                        continue;
                    }
                    if (block is IMyWarhead)
                    {
                        _warheads.Add(block as IMyWarhead);
                        continue;
                    }
                    if (block is IMyGyro)
                    {
                        _gyros.Add(block as IMyGyro);
                        ((IMyGyro)block).Enabled = true;
                        continue;
                    }
                    if (block is IMyBatteryBlock)
                    {
                        _batteryBlocks.Add(block as IMyBatteryBlock);
                        ((IMyBatteryBlock)block).Enabled = true;
                        ((IMyBatteryBlock)block).ChargeMode = ChargeMode.Discharge;
                        continue;
                    }                  
                    if (block is IMyProgrammableBlock)
                    {
                        _programmableBlocks.Add(block as IMyProgrammableBlock);
                        ((IMyProgrammableBlock)block).Enabled = true;
                        continue;
                    }
                    if (block is IMySoundBlock)
                    {
                        _soundBlocks.Add(block as IMySoundBlock);
                        ((IMySoundBlock)block).Enabled = true;
                        ((IMySoundBlock)block).SelectedSound = "ArcBotCyberSelfActDestr";
                        ((IMySoundBlock)block).LoopPeriod = 5000f;
                        ((IMySoundBlock)block).Play();
                        continue;
                    }

                }

                if (_nuke != null)
                    _nuke.Warheads = _warheads;

                foreach (var thruster in _thrusters)
                {
                    _acceleration += thruster.MaxEffectiveThrust;
                    thruster.ThrustOverridePercentage = 1f;
                }

                _connectors.ForEach(c => c.Disconnect());
                _blockList.ForEach(b => _mass += b.Mass);
                _mass += _cargeMass;
                _acceleration = _acceleration / _mass;


                return true;
            }

            public void Update()
            {
                if (!Launched)
                    return;

                if (!_missileSetup)
                {
                    _missileSetup = Setup();
                    if (_missileSetup)
                        this._connectors.ForEach(c => c.Enabled = false);
                    return;
                }


                if (_trackingDelay > _missileTicks)
                {
                    _missileTicks++;
                    return;
                }

                if (_iceManager != null)
                    _iceManager.Update();         

                RangeCheck();
                Guide();
                
            }


            private Vector3D GetPosition()
            {
                if (Merge == null | Merge.Closed)
                    return Vector3D.Zero;

                return Merge.CubeGrid.WorldVolume.Center;
            }

            
            private bool soundStarted = false;
            private void PlaySounds()
            {
                if(!soundStarted)
                    soundStarted = true;

                foreach(var soundblock in _soundBlocks)
                {
                    soundblock.Play();
                }
            }

            private void RangeCheck()
            {
                if (_nuke != null)
                    _nuke.Update();

                if (DistanceToTarget < _detonationDistance || _nukeOverride)
                {
                    if(_nuke != null)
                        _nuke.Detonate();
                }
            }


            public void ReassignTarget(long entityId, Vector3D targetLocation)
            {
                TargetId = entityId;
                TargetPosition = targetLocation;
            }

            private void Guide()
            {

                var missileVelocity = (GetPosition() - _lastPosition) / _updateSpeed;
                var targetVelocity = Vector3D.Zero;
               
                if (_ticksSinceLastUpdate > 1)
                {
                        targetVelocity = _lastTargetVelocity;
                }                    
                else
                {
                    targetVelocity = (TargetPosition - _lastTargetPosition) / (_updateSpeed * _ticksSinceLastUpdate);
                    _lastTargetVelocity = targetVelocity;
                }

                _lastLOS = Vector3D.Normalize(_lastTargetPosition - _lastPosition);
                _currentLOS = Vector3D.Normalize(TargetPosition - GetPosition());

                var relativeVelocity = Vector3D.Normalize(targetVelocity - missileVelocity);

                Vector3D am = new Vector3D(1, 0, 0);
                double losRate;
                Vector3D losDelta;

                if (_lastLOS.Length() == 0)
                {
                    losDelta = new Vector3D(0, 0, 0);
                    losRate = 0.0;
                }
                else
                {
                    losDelta = _currentLOS - _lastLOS;
                    losRate = losDelta.Length() / _updateSpeed;
                }


                double closingVelocity = (targetVelocity - missileVelocity).Length();

                Vector3D GravityComp = - ExternalReference.GetNaturalGravity();
                Vector3D LateralDirection = Vector3D.Normalize(Vector3D.Cross(Vector3D.Cross(relativeVelocity, _currentLOS), relativeVelocity));
                Vector3D lateralAcceleration = LateralDirection * _pngGain * losRate * closingVelocity + losDelta * 9.8 * (0.5 * _pngGain);

                double oversteerRequirement = (lateralAcceleration).Length() / _acceleration;
                if (oversteerRequirement > 0.98)
                {
                    lateralAcceleration = _acceleration * Vector3D.Normalize(lateralAcceleration + (oversteerRequirement * Vector3D.Normalize(-missileVelocity)) * 40);
                }

                Func<Vector3D, Vector3D, double> vectorProjectionScalar = (@in, Axis_norm) =>
                {
                    double @out = Vector3D.Dot(@in, Axis_norm);
                    if (double.IsNaN(@out))
                    {
                        @out = 0;
                    }
                    return @out;
                };

                double thrusterPower = vectorProjectionScalar(_forwardVector, Vector3D.Normalize(lateralAcceleration));

                thrusterPower = (_thrusters.First().CubeGrid.GridSizeEnum == MyCubeSize.Large) ? MathHelper.Clamp(thrusterPower, 0.9, 1) : thrusterPower;

                thrusterPower = MathHelper.Clamp(thrusterPower, 0.4, 1);
                foreach (var thruster in _thrusters)
                {
                    if (thruster.ThrustOverride != (thruster.MaxThrust * thrusterPower))
                    {
                        thruster.ThrustOverride = (float)(thruster.MaxThrust * thrusterPower);
                    }
                }

                double RejectedAccel = Math.Sqrt(_acceleration * _acceleration - lateralAcceleration.LengthSquared());
                if (double.IsNaN(RejectedAccel))
                {
                    RejectedAccel = 0;
                }
                lateralAcceleration = lateralAcceleration + _currentLOS * RejectedAccel;


                am = Vector3D.Normalize(lateralAcceleration + GravityComp);

                double Yaw; double Pitch;
                _gyros.RemoveAll(g => g.Closed);
                try
                {
                    CalculateGyroRotation(am, 18, 0.3, _gyros, _lastYaw, _lastPitch, out Pitch, out Yaw);

                    _lastTargetPosition = TargetPosition;
                    _lastPosition = GetPosition();
                    _lastYaw = Yaw;
                    _lastPitch = Pitch;
                }
                catch { }
            }


            private void CalculateGyroRotation(Vector3D targetDirection, double proportionalGain, double dampingGain, List<IMyGyro> gyroscopes, double previousYaw, double previousPitch, out double newPitch, out double newYaw)
            {
                newPitch = 0;
                newYaw = 0;

                _upVector = _thrusters.First().WorldMatrix.Up;
                _forwardVector = _thrusters.First().WorldMatrix.Backward;

                Quaternion shipOrientation = Quaternion.CreateFromForwardUp(_forwardVector, _upVector);
                var inverseOrientation = Quaternion.Inverse(shipOrientation);

                Vector3D transformedDirection = targetDirection;
                Vector3D referenceFrameDirection = Vector3D.Transform(transformedDirection, inverseOrientation);

                double shipForwardAzimuth = 0;
                double shipForwardElevation = 0;
                Vector3D.GetAzimuthAndElevation(referenceFrameDirection, out shipForwardAzimuth, out shipForwardElevation);

                newYaw = shipForwardAzimuth;
                newPitch = shipForwardElevation;

                shipForwardAzimuth += dampingGain * ((shipForwardAzimuth - previousYaw) / _updateSpeed);
                shipForwardElevation += dampingGain * ((shipForwardElevation - previousPitch) / _updateSpeed);


                _currentRoll += _spin;
                if (_currentRoll > Math.PI * 2)
                    _currentRoll -= Math.PI * 2;

                var referenceMatrix = MatrixD.CreateWorld(_thrusters.First().GetPosition(), (Vector3)_forwardVector, (Vector3)_upVector).GetOrientation();
                var pitchYawRollVector = Vector3.Transform(new Vector3D(shipForwardElevation, shipForwardAzimuth, _currentRoll), referenceMatrix);
                foreach (var gyroscope in gyroscopes)
                {
                    var transformedVector = Vector3.Transform(pitchYawRollVector, Matrix.Transpose(gyroscope.WorldMatrix.GetOrientation()));
                    if (double.IsNaN(transformedVector.X) || double.IsNaN(transformedVector.Y) || double.IsNaN(transformedVector.Z))
                    {
                        continue;
                    }
                    gyroscope.Pitch = (float)MathHelper.Clamp((-transformedVector.X) * proportionalGain, -1000, 1000);
                    gyroscope.Yaw = (float)MathHelper.Clamp(((-transformedVector.Y)) * proportionalGain, -1000, 1000);
                    gyroscope.Roll = (float)MathHelper.Clamp(((-transformedVector.Z)) * proportionalGain, -1000, 1000);
                    gyroscope.GyroOverride = true;
                }
            }

            IceManager _iceManager;
            Nuke _nuke;

            private double _spin = 0;
            private long _ticksSinceLastUpdate = 1;
            private const double _updateSpeed = 0.016;
            private bool _missileSetup = false;
            private double _lastYaw = 0;
            private double _lastPitch = 0;
            private double _currentRoll = 0;
            private double _pngGain = 2.5;
            private double _mass = 0;
            private double _cargeMass = 5000;
            private double _detonationDistance = 200;

            private bool _nukeOverride = false;
            private int _trackingDelay = 0;
            private int _missileTicks = 0;

            private double _acceleration = 0;
            private Vector3D _upVector = Vector3D.Zero;
            private Vector3D _currentLOS = Vector3D.Zero;
            private Vector3D _lastLOS = Vector3D.Zero;
            private Vector3D _lastTargetPosition = Vector3D.Zero;
            private Vector3D _lastPosition = Vector3D.Zero;
            private List<IMyTerminalBlock> _blockList = new List<IMyTerminalBlock>(); //To filter on launch
            private Vector3D _forwardVector = Vector3D.Zero;
            private Vector3D _lastTargetVelocity = Vector3D.Zero;

            private List<IMySoundBlock> _soundBlocks = new List<IMySoundBlock>();   
            private List<IMyProgrammableBlock> _programmableBlocks = new List<IMyProgrammableBlock>();
            private List<IMyShipConnector> _connectors = new List<IMyShipConnector>();
            private List<IMyCargoContainer> _cargoContainers = new List<IMyCargoContainer>();
            private List<IMyGasTank> _hydrogenTanks = new List<IMyGasTank>();
            private List<IMyThrust> _thrusters = new List<IMyThrust>();
            private List<IMyWarhead> _warheads = new List<IMyWarhead>();
            private List<IMyGyro> _gyros = new List<IMyGyro>();
            private List<IMyBatteryBlock> _batteryBlocks = new List<IMyBatteryBlock>();
            private bool _tickWaited = false;

        }

        class IceManager
        {
            public IceManager()
            {
            }

            public List<IMyGasGenerator> Generators
            {
                get { return _generators; }
            }
            public IMyInventory IceInventory
            {
                get { return _iceInventory; }
                set { _iceInventory = value; }
            }

            public void Update()
            {
                TransferIce();
            }
            private void TransferIce()
            {
                _generators.RemoveAll(g => g.Closed);
                foreach(var generator in _generators)
                {
                    if (generator.GetInventory().ItemCount != 0)
                        continue;

                    var item = _iceInventory.FindItem(IceDef);
                    if (item == null)
                        break;

                    _iceInventory.TransferItemTo(generator.GetInventory(), item.Value, (MyFixedPoint)0.1f);
                }

            }

            private MyItemType IceDef = MyItemType.Parse("MyObjectBuilder_Ore/Ice");
            IMyInventory _iceInventory;
            List<IMyGasGenerator> _generators = new List<IMyGasGenerator>();
        }


        class Nuke
        {
            public List<IMyWarhead> Warheads
            {
                get { return _warheads; }
                set { _warheads = value; }
            }
            public Nuke(IMyShipConnector connector)
            {
                _connector = connector;
                _inventory = _connector.GetInventory();
            }

            public void Update()
            {
                DetonateWarheads();
            }
            private void DetonateWarheads()
            {
                if (!_detonating)
                    return;
                _connector.Enabled = true;

                if (_inventory.ItemCount == 0)
                    foreach (var warhead in _warheads)
                        warhead.Detonate();
            }

            public void Detonate()
            {
                _connector.Enabled = true;
                _connector.ThrowOut = true;
                _detonating = true;
            }

            private IMyInventory _inventory;
            private bool _detonating = false;
            private IMyShipConnector _connector;
            private List<IMyWarhead> _warheads;
        }

        class RaycastHoming //thanks whiplash
        {
            public TargetingStatus Status { get; private set; } = TargetingStatus.NotLocked;
            public Vector3D TargetPosition
            {
                get
                {
                    return OffsetTargeting ? OffsetTargetPosition : TargetCenter;
                }
            }
            public double SearchScanSpread { get; set; } = 0;
            public Vector3D TargetCenter { get; private set; } = Vector3D.Zero;
            public Vector3D OffsetTargetPosition
            {
                get
                {
                    return TargetCenter + Vector3D.TransformNormal(PreciseModeOffset, _targetOrientation);
                }
            }
            public Vector3D TargetVelocity { get; private set; } = Vector3D.Zero;
            public Vector3D HitPosition { get; private set; } = Vector3D.Zero;
            public Vector3D PreciseModeOffset { get; private set; } = Vector3D.Zero;
            public string TargetName { get; private set; } = "";
            public bool OffsetTargeting = false;
            public bool MissedLastScan { get; private set; } = false;
            public bool LockLost { get; private set; } = false;
            public bool IsScanning { get; private set; } = false;
            public double TimeSinceLastLock { get; private set; } = 0;
            public long TicksSinceLastLock { get; private set;} = 0;
            public double TargetSize { get; private set; } = 0;
            public double MaxRange { get; private set; }
            public double MinRange { get; private set; }
            public long TargetId { get; private set; } = 0;
            public double AutoScanInterval { get; private set; } = 0;
            public double MaxTimeForLockBreak { get; private set; }
            public MyRelationsBetweenPlayerAndBlock TargetRelation { get; private set; }
            public MyDetectedEntityType TargetType { get; private set; }
            public long TimeSinceLastRaycast { 
                get
                {
                    return (_currentTimeStamp - _lastTimeStamp);
                } 
            }

            public enum TargetingStatus { NotLocked, Locked, TooClose };
            enum AimMode { Center, Offset, OffsetRelative };

            AimMode _currentAimMode = AimMode.Center;

            readonly HashSet<MyDetectedEntityType> _targetFilter = new HashSet<MyDetectedEntityType>();
            readonly List<IMyCameraBlock> _availableCameras = new List<IMyCameraBlock>();
            readonly Random _rngeesus = new Random();

            MatrixD _targetOrientation;
            HashSet<long> _gridIDsToIgnore = new HashSet<long>();
            double _timeSinceLastScan = 0;
            bool _manualLockOverride = false;
            bool _fudgeVectorSwitch = false;
            long _lastTimeStamp = 0;
            long _currentTimeStamp = 0;
            long _ticks = 0;
            double AutoScanScaleFactor
            {
                get
                {
                    return MissedLastScan ? 0.8 : 1.1;
                }
            }

            public RaycastHoming(double maxRange, double maxTimeForLockBreak = 3, double minRange = 0, long gridIDToIgnore = 0)
            {
                MinRange = minRange;
                MaxRange = maxRange;
                MaxTimeForLockBreak = maxTimeForLockBreak;
                AddIgnoredGridID(gridIDToIgnore);
            }

            public void SetInitialLockParameters(Vector3D hitPosition, Vector3D targetVelocity, Vector3D offset, double timeSinceLastLock, long targetId)
            {
                TargetCenter = hitPosition;
                HitPosition = hitPosition;
                PreciseModeOffset = offset;
                TargetVelocity = targetVelocity;
                TimeSinceLastLock = timeSinceLastLock;
                _manualLockOverride = true;
                IsScanning = true;
                TargetId = targetId;
            }

            public void AddIgnoredGridID(long id)
            {
                _gridIDsToIgnore.Add(id);
            }

            public void ClearIgnoredGridIDs()
            {
                _gridIDsToIgnore.Clear();
            }

            public void AddEntityTypeToFilter(params MyDetectedEntityType[] types)
            {
                foreach (var type in types)
                {
                    _targetFilter.Add(type);
                }
            }

            public void AcknowledgeLockLost()
            {
                LockLost = false;
            }

            public void LockOn()
            {
                ClearLockInternal();
                LockLost = false;
                IsScanning = true;
            }

            public void ClearLock()
            {
                ClearLockInternal();
                LockLost = false;
            }

            void ClearLockInternal()
            {
                IsScanning = false;
                Status = TargetingStatus.NotLocked;
                MissedLastScan = false;
                TimeSinceLastLock = 0;
                TargetSize = 0;
                HitPosition = Vector3D.Zero;
                TargetId = 0;
                _timeSinceLastScan = 141;
                _currentAimMode = AimMode.Center;
                TargetRelation = MyRelationsBetweenPlayerAndBlock.NoOwnership;
                TargetType = MyDetectedEntityType.None;
            }

            double RndDbl()
            {
                return 2 * _rngeesus.NextDouble() - 1;
            }

            double GaussRnd()
            {
                return (RndDbl() + RndDbl() + RndDbl()) / 3.0;
            }

            Vector3D CalculateFudgeVector(Vector3D targetDirection, double fudgeFactor = 5)
            {
                _fudgeVectorSwitch = !_fudgeVectorSwitch;

                if (!_fudgeVectorSwitch)
                    return Vector3D.Zero;

                var perpVector1 = Vector3D.CalculatePerpendicularVector(targetDirection);
                var perpVector2 = Vector3D.Cross(perpVector1, targetDirection);
                if (!Vector3D.IsUnit(ref perpVector2))
                    perpVector2.Normalize();

                var randomVector = GaussRnd() * perpVector1 + GaussRnd() * perpVector2;
                return randomVector * fudgeFactor * TimeSinceLastLock;
            }

            Vector3D GetSearchPos(Vector3D origin, Vector3D direction, IMyCameraBlock camera)
            {
                Vector3D scanPos = origin + direction * MaxRange;
                if (SearchScanSpread < 1e-2)
                {
                    return scanPos;
                }
                return scanPos + (camera.WorldMatrix.Left * GaussRnd() + camera.WorldMatrix.Up * GaussRnd()) * SearchScanSpread;
            }

            IMyTerminalBlock GetReference(List<IMyCameraBlock> cameraList, List<IMyShipController> shipControllers, IMyTerminalBlock referenceBlock)
            {
                IMyTerminalBlock controlledCam = GetControlledCamera(cameraList);
                if (controlledCam != null)
                    return controlledCam;

                if (referenceBlock != null)
                    return referenceBlock;

                return GetControlledShipController(shipControllers);
            }

            IMyCameraBlock SelectCamera()
            {
                if (_availableCameras.Count == 0)
                {
                    _timeSinceLastScan = 100000;
                    MissedLastScan = true;
                    return null;
                }

                return GetCameraWithMaxRange(_availableCameras);
            }

            void SetAutoScanInterval(double scanRange, IMyCameraBlock camera)
            {
                AutoScanInterval = scanRange / (1000.0 * camera.RaycastTimeMultiplier) / _availableCameras.Count * AutoScanScaleFactor;
            }

            bool DoLockScan(List<IMyCameraBlock> cameraList, out MyDetectedEntityInfo info, out IMyCameraBlock camera)
            {
                info = default(MyDetectedEntityInfo);

                #region Scan position selection
                Vector3D scanPosition;
                switch (_currentAimMode)
                {
                    case AimMode.Offset:
                        scanPosition = HitPosition;
                        break;
                    case AimMode.OffsetRelative:
                        scanPosition = OffsetTargetPosition;
                        break;
                    default:
                        scanPosition = TargetCenter;
                        break;
                }
                scanPosition += TargetVelocity * TimeSinceLastLock;

                if (MissedLastScan)
                {
                    scanPosition += CalculateFudgeVector(scanPosition - cameraList[0].GetPosition());
                }
                #endregion

                #region Camera selection
                GetCamerasInDirection(cameraList, _availableCameras, scanPosition, true);

                camera = SelectCamera();
                if (camera == null)
                {
                    return false;
                }
                #endregion

                #region Scanning
                // We adjust the scan position to scan a bit past the target so we are more likely to hit if it is moving away
                Vector3D adjustedTargetPos = scanPosition + Vector3D.Normalize(scanPosition - camera.GetPosition()) * 2 * TargetSize;
                double scanRange = (adjustedTargetPos - camera.GetPosition()).Length();

                SetAutoScanInterval(scanRange, camera);

                if (camera.AvailableScanRange >= scanRange &&
                    _timeSinceLastScan >= AutoScanInterval)
                {
                    info = camera.Raycast(adjustedTargetPos);
                    return true;
                }
                return false;
                #endregion
            }

            bool DoSearchScan(List<IMyCameraBlock> cameraList, IMyTerminalBlock reference, out MyDetectedEntityInfo info, out IMyCameraBlock camera)
            {
                info = default(MyDetectedEntityInfo);

                #region Camera selection
                if (reference != null)
                {
                    GetCamerasInDirection(cameraList, _availableCameras, reference.WorldMatrix.Forward);
                }
                else
                {
                    _availableCameras.Clear();
                    _availableCameras.AddRange(cameraList);
                }

                camera = SelectCamera();
                if (camera == null)
                {
                    return false;
                }
                #endregion

                #region Scanning
                SetAutoScanInterval(MaxRange, camera);

                if (camera.AvailableScanRange >= MaxRange &&
                    _timeSinceLastScan >= AutoScanInterval)
                {
                    if (reference != null)
                    {
                        info = camera.Raycast(GetSearchPos(reference.GetPosition(), reference.WorldMatrix.Forward, camera));
                    }
                    else
                    {
                        info = camera.Raycast(MaxRange);
                    }

                    return true;
                }
                return false;
                #endregion
            }

            public void UpdateTargetStateVectors(Vector3D position, Vector3D hitPosition, Vector3D velocity, double timeSinceLock = 0)
            {
                TicksSinceLastLock = 1;
                TargetCenter = position;
                HitPosition = hitPosition;
                TargetVelocity = velocity;
                TimeSinceLastLock = timeSinceLock;
            }

            void ProcessScanData(MyDetectedEntityInfo info, IMyTerminalBlock reference, Vector3D scanOrigin)
            {
                // Validate target and assign values
                if (info.IsEmpty() ||
                    _targetFilter.Contains(info.Type) ||
                    _gridIDsToIgnore.Contains(info.EntityId))
                {
                    MissedLastScan = true;
                    CycleAimMode();
                }
                else
                {
                    if (Vector3D.DistanceSquared(info.Position, scanOrigin) < MinRange * MinRange && Status != TargetingStatus.Locked)
                    {
                        Status = TargetingStatus.TooClose;
                        return;
                    }

                    if (info.EntityId != TargetId)
                    {
                        if (Status == TargetingStatus.Locked)
                        {
                            MissedLastScan = true;
                            CycleAimMode();
                            return;
                        }
                        else if (_manualLockOverride)
                        {
                            MissedLastScan = true;
                            return;
                        }
                    }

                    MissedLastScan = false;
                    UpdateTargetStateVectors(info.Position, info.HitPosition.Value, info.Velocity);

                    _lastTimeStamp = _currentTimeStamp;
                    _currentTimeStamp = _ticks;

                    TargetSize = info.BoundingBox.Size.Length();
                    _targetOrientation = info.Orientation;

                    if (Status != TargetingStatus.Locked) // Initial lockon
                    {
                        Status = TargetingStatus.Locked;
                        TargetId = info.EntityId;
                        TargetRelation = info.Relationship;
                        TargetType = info.Type;
                        TargetName = info.Name;

                        // Compute aim offset
                        if (!_manualLockOverride)
                        {
                            Vector3D hitPosOffset = reference == null ? Vector3D.Zero : VectorRejection(reference.GetPosition() - scanOrigin, HitPosition - scanOrigin);
                            PreciseModeOffset = Vector3D.TransformNormal(info.HitPosition.Value + hitPosOffset - TargetCenter, MatrixD.Transpose(_targetOrientation));
                        }
                    }

                    _manualLockOverride = false;
                }
            }

            void CycleAimMode()
            {
                _currentAimMode = (AimMode)((int)(_currentAimMode + 1) % 3);
            }

            public void Update(double timeStep, List<IMyCameraBlock> cameraList, List<IMyShipController> shipControllers, IMyTerminalBlock referenceBlock = null)
            {
                _timeSinceLastScan += timeStep;
                _ticks++;

                if (!IsScanning)
                    return;

                TicksSinceLastLock++;
                TimeSinceLastLock += timeStep;

                if (cameraList.Count == 0)
                    return;

                // Check for lock lost
                if (TimeSinceLastLock > (MaxTimeForLockBreak + AutoScanInterval) && (Status == TargetingStatus.Locked || _manualLockOverride))
                {
                    LockLost = true; // TODO: Change this to a callback
                    ClearLockInternal();
                    return;
                }

                IMyTerminalBlock reference = GetReference(cameraList, shipControllers, referenceBlock);

                MyDetectedEntityInfo info;
                IMyCameraBlock camera;
                bool scanned;
                if (Status == TargetingStatus.Locked || _manualLockOverride)
                {
                    scanned = DoLockScan(cameraList, out info, out camera);
                }
                else
                {
                    scanned = DoSearchScan(cameraList, reference, out info, out camera);
                }

                if (!scanned)
                {
                    return;
                }
                _timeSinceLastScan = 0;

                ProcessScanData(info, reference, camera.GetPosition());
            }

            void GetCamerasInDirection(List<IMyCameraBlock> allCameras, List<IMyCameraBlock> availableCameras, Vector3D testVector, bool vectorIsPosition = false)
            {
                availableCameras.Clear();

                foreach (var c in allCameras)
                {
                    if (c.Closed)
                        continue;

                    if (TestCameraAngles(c, vectorIsPosition ? testVector - c.GetPosition() : testVector))
                        availableCameras.Add(c);
                }
            }

            bool TestCameraAngles(IMyCameraBlock camera, Vector3D direction)
            {
                Vector3D local = Vector3D.Rotate(direction, MatrixD.Transpose(camera.WorldMatrix));

                if (local.Z > 0)
                    return false;

                var yawTan = Math.Abs(local.X / local.Z);
                var localSq = local * local;
                var pitchTanSq = localSq.Y / (localSq.X + localSq.Z);

                return yawTan <= 1 && pitchTanSq <= 1;
            }

            IMyCameraBlock GetCameraWithMaxRange(List<IMyCameraBlock> cameras)
            {
                double maxRange = 0;
                IMyCameraBlock maxRangeCamera = null;
                foreach (var c in cameras)
                {
                    if (c.AvailableScanRange > maxRange)
                    {
                        maxRangeCamera = c;
                        maxRange = maxRangeCamera.AvailableScanRange;
                    }
                }

                return maxRangeCamera;
            }

            IMyCameraBlock GetControlledCamera(List<IMyCameraBlock> cameras)
            {
                foreach (var c in cameras)
                {
                    if (c.Closed)
                        continue;

                    if (c.IsActive)
                        return c;
                }
                return null;
            }

            IMyShipController GetControlledShipController(List<IMyShipController> controllers)
            {
                if (controllers.Count == 0)
                    return null;

                IMyShipController mainController = null;
                IMyShipController controlled = null;

                foreach (var sc in controllers)
                {
                    if (sc.IsUnderControl && sc.CanControlShip)
                    {
                        if (controlled == null)
                        {
                            controlled = sc;
                        }

                        if (sc.IsMainCockpit)
                        {
                            mainController = sc; // Only one per grid so no null check needed
                        }
                    }
                }

                if (mainController != null)
                    return mainController;

                if (controlled != null)
                    return controlled;

                return controllers[0];
            }

            public static Vector3D VectorRejection(Vector3D a, Vector3D b)
            {
                if (Vector3D.IsZero(a) || Vector3D.IsZero(b))
                    return Vector3D.Zero;

                return a - a.Dot(b) / b.LengthSquared() * b;
            }
        }


    }
}
